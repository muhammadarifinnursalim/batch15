<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Agen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
  </head>
  <body>
  <?php
$konek = mysqli_connect("localhost","root","","transaction");
$tampil = "SELECT * FROM agents ORDER BY AGENT_CODE";
$hasil  = mysqli_query($konek, $tampil);
$total  = mysqli_num_rows($hasil);

echo "<table class= 'table table-striped'>
      <tr>
      <th>ID AGENT</th>
        <th>NAMA AGENT</th>
 	      <th>AREA AGENT</th>
           <th>AKSI</th>
      </tr>";

// nomor awal untuk pengurutan
$no = 1;

// Tampilkan Data
while ($data=mysqli_fetch_array($hasil)){
  echo "<tr>
  <td>$data[AGENT_CODE]</td>
  <td>$data[AGENT_NAME]</td>
  <td>$data[WORKING_AREA]</td>

          <td><a href=\"edit_data.php?id=$data[AGENT_CODE]\">Edit</a> | 
              <a href=\"hapus_data.php?id=$data[AGENT_CODE]\">Hapus</a></td> 
        </tr>";
         // tambahkan $no dengan 1
         $no++;
}
echo "</table>";
?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
  </body>
</html>