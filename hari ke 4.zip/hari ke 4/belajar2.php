<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "transaction";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Koneksi Gagal: " . $conn->connect_error);
}

$sql = "SELECT AGENT_CODE, AGENT_NAME, WORKING_AREA FROM agents";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "Agent Code: " . $row["AGENT_CODE"]. " - Agent Name " . $row["AGENT_NAME"]. " Working Area " . $row["WORKING_AREA"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();
?>