<?php
$servername = "localhost";
$username = "root";
$password = "";

// Koneksi Ke My SQL
$conn = new mysqli($servername, $username, $password);

// Cek Koneksinya
if ($conn->connect_error) {
  die("Koneksi Gagal: " . $conn->connect_error);
}
echo "Koneksi Berhasil";
?>