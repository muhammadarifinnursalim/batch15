<?php
$konek = mysqli_connect("localhost","root","","latihan");

// ambil id dari hasil klik link Hapus
$id    = $_GET['id'];

$hapus = "DELETE FROM tamu WHERE id_tamu='$id'";
$hasil = mysqli_query($konek, $hapus);

// apabila query untuk menghapus data benar
if ($hasil){ 
	// lakukan redirect
	header("location:tampil.php");
}
else{
  echo "Hapus Data Gagal";
}
?>
