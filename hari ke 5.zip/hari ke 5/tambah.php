<html>
<title>Buku Tamu DIgital</title>
<link href="style.css" rel="stylesheet" type="text/css">
<body>

<h3>Form Tambah Data Tamu</h3>
<form method="GET" action="proses.php">
<table>
<tr><td>Nama</td><td>: <input type="text" name="nama"></td></tr>
<tr><td>E-mail</td><td>: <input type="text" name="email"></td></tr> 
<tr><td>Keterangan</td><td>: <textarea name="pesan" rows="5" cols="30"></textarea></td></tr>
<tr><td></td><td><input type="submit" value="Kirim"></td></tr>
</table>
</form>
