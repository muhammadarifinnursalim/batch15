<html>
<title>Buku Tamu DIgital</title>
<link href="style.css" rel="stylesheet" type="text/css">
<body>

<h3>Data Tamu Yang Hadir</h3>
<p><a href="tambah.php">Input Data Tamu</a></p>

<?php
$konek = mysqli_connect("localhost","root","","latihan");

$tampil = "SELECT * FROM tamu ORDER BY id_tamu";
$hasil  = mysqli_query($konek, $tampil);
$total  = mysqli_num_rows($hasil);

echo "<table>
      <tr>
        <th>No</th>
        <th>Nama</th>
 	      <th>E-mail</th>
        <th>Keterangan</th>
        <th>Aksi</th>
      </tr>";

// nomor awal untuk pengurutan
$no = 1;

// tampilkan data 
while ($data=mysqli_fetch_array($hasil)){
  echo "<tr>
          <td>$no</td>          
          <td>$data[nama]</td>
          <td>$data[email]</td>
          <td>$data[pesan]</td>
          <td><a href=\"edit.php?id=$data[id_tamu]\">Edit</a> | 
              <a href=\"hapus.php?id=$data[id_tamu]\">Hapus</a></td> 
        </tr>";
        
        // tambahkan $no dengan 1
        $no++;
}

echo "</table>";

echo "<p>Jumlah Tamu: <b>$total</b> Orang</p>";
?>
