<?php
// koneksi ke database
$konek = mysqli_connect("localhost","root","","latihan");

// ambil variabel yang dikirim dari form
$nama  = $_GET['nama'];
$email = $_GET['email'];
$pesan = $_GET['pesan'];

$input = "INSERT INTO tamu(nama,email,pesan) VALUES('$nama','$email','$pesan')";
$hasil = mysqli_query($konek, $input);

// apabila query untuk menginput data benar
if ($hasil){ 
	// lakukan redirect
	header("location:tampil.php");
}
else{
  echo "Input Data Gagal";
}
?>
